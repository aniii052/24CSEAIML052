# Program to find real roots of a quadratic equation without math module

a = float(input("Enter coefficient a: "))
b = float(input("Enter coefficient b: "))
c = float(input("Enter coefficient c: "))

d = b*b - 4*a*c   # Discriminant

if d > 0:
    r1 = (-b + d**0.5) / (2*a)
    r2 = (-b - d**0.5) / (2*a)
    print("Two real and distinct roots:")
    print("Root 1 =", r1)
    print("Root 2 =", r2)

elif d == 0:
    r = -b / (2*a)
    print("Two real and equal roots:")
    print("Root =", r)

else:
    print("No real roots (roots are imaginary)")
